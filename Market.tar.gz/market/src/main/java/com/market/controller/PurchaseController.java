package com.market.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.market.entity.Purchase;
import com.market.service.PurchaseService;

@Controller
public class PurchaseController {

	@Autowired
	private PurchaseService purchaseService;
	@Autowired
	private static String selName = "";
	

	@InitBinder
	public void initBinder(WebDataBinder binder) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		dateFormat.setLenient(false);// 是否严格解析时间 false则严格解析 true宽松解析
		binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true));
	}


	// 查询全部并分页
	@RequestMapping("/purchase")
	public String findAllPurchase(Model model, @RequestParam(defaultValue = "1", value = "pageNum") Integer pageNum) {
		model.addAttribute("currUser", AdminController.ADMIN);
		PageHelper.startPage(pageNum, 5);
		List<Purchase> list = purchaseService.findAllPurchase();
		PageInfo<Purchase> pageInfo = new PageInfo<Purchase>(list);
		model.addAttribute("pageInfo", pageInfo);
		return "html/purchase";
	}
	

	// 删除
	@RequestMapping(value = "/del_purchase/{id}")
	public String delPurchase(@PathVariable("id") int id) {
		purchaseService.del(id);
		System.out.println("删除id为: " + id + " 的学员");
		return "redirect:/purchase";
	}
	
	// 删除
	@RequestMapping(value = "/select_del_purchase/{id}")
	public String selectDelPurchase(@PathVariable("id") int id) {
		purchaseService.del(id);
		System.out.println("删除id为: " + id + " 的学员");
		return "redirect:/select_purchase";
	}




	// 添加操作
	@RequestMapping("/add_purchase")
	public String addPurchase(Purchase purchase) {
		purchaseService.add(purchase);
		System.out.println("添加sno为: " + purchase.getPur_no() + " 的学员");
		return "redirect:/purchase";
	}


	// 更新操作
	@RequestMapping("/update_purchase")
	public String update(Purchase purchase) {
		// System.out.println("del_id: "+goods.getId());
		System.out.println("更新id为: " + purchase.getPur_no()+ " 的学员");
		System.out.println(purchase);
		purchaseService.update(purchase);
		
		return "redirect:/purchase";

	}



	// 根据sno及及sname模糊查询
	@RequestMapping("/select_purchase")
	private String findByName(String sel_purchase_name, Model model,
			@RequestParam(defaultValue = "1", value = "pageNum") Integer pageNum) {
		model.addAttribute("currUser", AdminController.ADMIN);
		if (sel_purchase_name != null) {
			selName = sel_purchase_name;
		}

		PageHelper.startPage(pageNum, 5);
		List<Purchase> list = purchaseService.findByName(selName);
		System.out.println(list);
		System.out.println("查询sno或sname Like: " + selName + " 的学员");
		PageInfo<Purchase> selectInfo = new PageInfo<Purchase>(list);
		model.addAttribute("pageInfo", selectInfo);
		model.addAttribute("selName", selName);
		return "html/purchase";

	}




}
