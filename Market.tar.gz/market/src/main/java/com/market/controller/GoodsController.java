package com.market.controller;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.market.entity.Goods;
import com.market.service.GoodsService;

@Controller
public class GoodsController {

	@Autowired
	private GoodsService goodsService;
	@Autowired
	private static String selName = "";
	

	@InitBinder
	public void initBinder(WebDataBinder binder) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		dateFormat.setLenient(false);// 是否严格解析时间 false则严格解析 true宽松解析
		binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true));
	}

	// @RequestMapping("/findAll")
	// public String findAll(ModelMap map) {
	//
	// List<Student> goods=goodsService.findAllGoods();
	// System.out.println(goods.size());
	// map.addAttribute("goods", students);
	// return "html/main";
	//
	// }

	// 查询全部并分页
//	@RequestMapping("/findAll")
//	public String findAll(Model model, @RequestParam(defaultValue = "1", value = "pageNum") Integer pageNum) {
//		PageHelper.startPage(pageNum, 5);
//		List<Student> list = goodsService.findAllGoods();
//		PageInfo<Student> pageInfo = new PageInfo<Student>(list);
//		model.addAttribute("pageInfo", pageInfo);
//		return "html/main";
//	}
//	
	// 查询全部并分页
	@RequestMapping("/goods")
	public String findAllGoods(Model model, @RequestParam(defaultValue = "1", value = "pageNum") Integer pageNum) {
		model.addAttribute("currUser", AdminController.ADMIN);
		PageHelper.startPage(pageNum, 5);
		List<Goods> list = goodsService.findAllGoods();
		PageInfo<Goods> pageInfo = new PageInfo<Goods>(list);
		model.addAttribute("pageInfo", pageInfo);

		return "html/goods";
	}
	
	// 查询全部并分页
//	@RequestMapping("/goods")
//	public String goods(Model model) {
//		List<Goods> list = goodsService.findAllGoods();
//		model.addAttribute("list", list);
//		return "html/goods";
//	}
	



	
	// 删除
	@RequestMapping(value = "/del_goods/{id}")
	public String delGoods(@PathVariable("id") int id) {
		goodsService.del(id);
		System.out.println("删除id为: " + id + " 的学员");
		return "redirect:/goods";
	}
	
	// 删除
	@RequestMapping(value = "/select_del_goods/{id}")
	public String selectDelGoods(@PathVariable("id") int id) {
		goodsService.del(id);
		System.out.println("删除id为: " + id + " 的学员");
		return "redirect:/select_goods";
	}




	// 添加操作
	@RequestMapping("/add_goods")
	public String addGoods(Goods goods) {
		goodsService.add(goods);
		System.out.println("添加sno为: " + goods.getG_no() + " 的学员");
		return "redirect:/goods";
		//return "html/goods";
	}
	






	// 更新操作
	@RequestMapping("/update_goods")
	public String update(Goods goods) {
		// System.out.println("del_id: "+goods.getId());
		System.out.println("更新id为: " + goods.getG_no() + " 的学员");
		goodsService.update(goods);
		return "redirect:/goods";

	}
	@RequestMapping("/select_update_goods")
	public String select_update(Goods goods) {
		// System.out.println("del_id: "+goods.getId());
		System.out.println("更新id为: " + goods.getG_no() + " 的学员");
		goodsService.update(goods);
		return "redirect:/select_goods";

	}


	// 根据sno及及sname模糊查询
	@RequestMapping("/select_goods")
	private String findByName(String sel_goods_name, Model model,
			@RequestParam(defaultValue = "1", value = "pageNum") Integer pageNum) {
		model.addAttribute("currUser", AdminController.ADMIN);
		if (sel_goods_name != null) {
			selName = sel_goods_name;
		}

		PageHelper.startPage(pageNum, 5);
		List<Goods> list = goodsService.findByName(selName);
		System.out.println("查询sno或sname Like: " + selName + " 的学员");
		PageInfo<Goods> selectInfo = new PageInfo<Goods>(list);
		model.addAttribute("pageInfo", selectInfo);
		model.addAttribute("selName", selName);
		return "html/select_goods";

	}




}
