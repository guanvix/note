package com.market.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.market.entity.Staff;
import com.market.service.StaffService;@Controller
public class StaffController {

	@Autowired
	private StaffService staffService;
	@Autowired
	private static String selName = "";
	

	@InitBinder
	public void initBinder(WebDataBinder binder) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		dateFormat.setLenient(false);// 是否严格解析时间 false则严格解析 true宽松解析
		binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true));
	}


	// 查询全部并分页
	@RequestMapping("/staff")
	public String findAllMember(Model model, @RequestParam(defaultValue = "1", value = "pageNum") Integer pageNum) {
		model.addAttribute("currUser", AdminController.ADMIN);
		PageHelper.startPage(pageNum, 5);
		List<Staff> list = staffService.findAllStaff();
		System.out.println(list);
		PageInfo<Staff> pageInfo = new PageInfo<Staff>(list);
		model.addAttribute("pageInfo", pageInfo);
		return "html/staff";
	}
	

//	// 删除
	@RequestMapping(value = "/del_staff/{id}")
	public String delMember(@PathVariable("id") int id) {
		staffService.del(id);
		System.out.println("删除id为: " + id + " 的学员");
		return "redirect:/staff";
	}
	
//	// 删除
//	@RequestMapping(value = "/select_del_member/{id}")
//	public String selectDelMember(@PathVariable("id") int id) {
//		memberService.del(id);
//		System.out.println("删除id为: " + id + " 的学员");
//		return "redirect:/select_member";
//	}
//
//
//
//
	// 添加操作
	@RequestMapping("/add_staff")
	public String addMember(Staff staff) {
		staffService.add(staff);
		System.out.println("添加sno为: " + staff.getS_no() + " 的学员");
		return "redirect:/staff";
	}
//
//
	// 更新操作
	@RequestMapping("/update_staff")
	public String update(Staff staff) {
		// System.out.println("del_id: "+goods.getId());
		System.out.println("更新id为: " + staff.getS_no()+ " 的学员");
		System.out.println(staff);
		staffService.update(staff);
		
		return "redirect:/staff";

	}
//
//
//
	// 根据sno及及sname模糊查询
	@RequestMapping("/select_staff")
	private String findByName(String sel_staff_name, Model model,
			@RequestParam(defaultValue = "1", value = "pageNum") Integer pageNum) {
		model.addAttribute("currUser", AdminController.ADMIN);
		if (sel_staff_name != null) {
			selName = sel_staff_name;
		}

		PageHelper.startPage(pageNum, 5);
		List<Staff> list = staffService.findByName(selName);
		System.out.println(list);
		System.out.println("查询sno或sname Like: " + selName + " 的学员");
		PageInfo<Staff> selectInfo = new PageInfo<Staff>(list);
		model.addAttribute("pageInfo", selectInfo);
		model.addAttribute("selName", selName);
		return "html/staff";

	}

//
//

}
