package com.market.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.market.entity.Exchange;
import com.market.service.ExchangeService;

@Controller
public class ExchangeController {

	@Autowired
	private ExchangeService exchangeService;
	@Autowired
	private static String selName = "";

	@InitBinder
	public void initBinder(WebDataBinder binder) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		dateFormat.setLenient(false);// 是否严格解析时间 false则严格解析 true宽松解析
		binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true));
	}

	// 查询全部并分页
	@RequestMapping("/exchange")
	public String findAllExchange(Model model, @RequestParam(defaultValue = "1", value = "pageNum") Integer pageNum) {
		model.addAttribute("currUser", AdminController.ADMIN);
		PageHelper.startPage(pageNum, 5);
		List<Exchange> list = exchangeService.findAllExchange();
		PageInfo<Exchange> pageInfo = new PageInfo<Exchange>(list);
		model.addAttribute("pageInfo", pageInfo);
		return "html/exchange";
	}
	
	// 删除
	@RequestMapping(value = "/del_exchange/{id}")
	public String delExchange(@PathVariable("id") int id) {
		exchangeService.del(id);
		System.out.println("删除id为: " + id + " 的学员");
		return "redirect:/exchange";
	}
	
	// 删除
	@RequestMapping(value = "/select_del_exchange/{id}")
	public String selectDelExchange(@PathVariable("id") int id) {
		exchangeService.del(id);
		System.out.println("删除id为: " + id + " 的学员");
		return "redirect:/select_exchange";
	}

	// 添加操作
	@RequestMapping("/add_exchange")
	public String addExchange(Exchange exchange) {
		System.out.println(exchange);
		exchangeService.add(exchange);
		System.out.println("添加sno为: " + exchange.getM_name() + " 的学员");
		return "redirect:/prize";
	}

	// 更新操作
	@RequestMapping("/update_exchange")
	public String update(Exchange exchange) {
		// System.out.println("del_id: "+goods.getId());
		System.out.println("更新id为: " + exchange.getE_no()+ " 的学员");
		System.out.println(exchange);
		exchangeService.update(exchange);
		
		return "redirect:/exchange";

	}
	// 根据sno及及sname模糊查询
	@RequestMapping("/select_exchange")
	private String findByName(String sel_exchange_name, Model model,
			@RequestParam(defaultValue = "1", value = "pageNum") Integer pageNum) {
		model.addAttribute("currUser", AdminController.ADMIN);
		if (sel_exchange_name != null) {
			selName = sel_exchange_name;
		}

		PageHelper.startPage(pageNum, 5);
		List<Exchange> list = exchangeService.findByName(selName);
		System.out.println("查询sno或sname Like: " + selName + " 的学员");
		PageInfo<Exchange> selectInfo = new PageInfo<Exchange>(list);
		model.addAttribute("pageInfo", selectInfo);
		model.addAttribute("selName", selName);
		return "html/exchange";

	}




}
