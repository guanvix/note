package com.market.controller;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.market.entity.Prize;
import com.market.service.PrizeService;

@Controller
public class PrizeController {

	@Autowired
	private PrizeService prizeService;
	@Autowired
	private static String selName = "";

	@InitBinder
	public void initBinder(WebDataBinder binder) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		dateFormat.setLenient(false);// 是否严格解析时间 false则严格解析 true宽松解析
		binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true));
	}

	// 查询全部并分页
	@RequestMapping("/prize")
	public String findAllPrize(Model model, @RequestParam(defaultValue = "1", value = "pageNum") Integer pageNum) {
		model.addAttribute("currUser", AdminController.ADMIN);
		PageHelper.startPage(pageNum, 5);
		List<Prize> list = prizeService.findAllPrize();
		PageInfo<Prize> pageInfo = new PageInfo<Prize>(list);
		model.addAttribute("pageInfo", pageInfo);
		return "html/prize";
	}
	
	// 删除
	@RequestMapping(value = "/del_prize/{id}")
	public String delPrize(@PathVariable("id") int id) {
		prizeService.del(id);
		System.out.println("删除id为: " + id + " 的学员");
		return "redirect:/prize";
	}
	
	// 删除
	@RequestMapping(value = "/select_del_prize/{id}")
	public String selectDelPrize(@PathVariable("id") int id) {
		prizeService.del(id);
		System.out.println("删除id为: " + id + " 的学员");
		return "redirect:/select_prize";
	}

	// 添加操作
	@RequestMapping("/add_prize")
	public String addPrize(Prize prize) {
		prizeService.add(prize);
		System.out.println("添加sno为: " + prize.getP_no() + " 的学员");
		return "redirect:/prize";
	}
	// 更新操作
	@RequestMapping("/update_prize")
	public String update(Prize prize) {
		// System.out.println("del_id: "+goods.getId());
		System.out.println("更新id为: " + prize.getP_no()+ " 的学员");
		System.out.println(prize);
		prizeService.update(prize);
		
		return "redirect:/prize";

	}

	// 根据sno及及sname模糊查询
	@RequestMapping("/select_prize")
	private String findByName(String sel_prize_name, Model model,
			@RequestParam(defaultValue = "1", value = "pageNum") Integer pageNum) {
		model.addAttribute("currUser", AdminController.ADMIN);
		if (sel_prize_name != null) {
			selName = sel_prize_name;
		}

		PageHelper.startPage(pageNum, 5);
		List<Prize> list = prizeService.findByName(selName);
		System.out.println("查询sno或sname Like: " + selName + " 的学员");
		PageInfo<Prize> selectInfo = new PageInfo<Prize>(list);
		model.addAttribute("pageInfo", selectInfo);
		model.addAttribute("selName", selName);
		return "html/prize";

	}




}
