package com.market.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.market.entity.Member;
import com.market.service.MemberService;

@Controller
public class MemberController {

	@Autowired
	private MemberService memberService;
	@Autowired
	private static String selName = "";
	

	@InitBinder
	public void initBinder(WebDataBinder binder) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		dateFormat.setLenient(false);// 是否严格解析时间 false则严格解析 true宽松解析
		binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true));
	}


	// 查询全部并分页
	@RequestMapping("/member")
	public String findAllMember(Model model, @RequestParam(defaultValue = "1", value = "pageNum") Integer pageNum) {
		model.addAttribute("currUser", AdminController.ADMIN);
		PageHelper.startPage(pageNum, 5);
		List<Member> list = memberService.findAllMember();
		PageInfo<Member> pageInfo = new PageInfo<Member>(list);
		model.addAttribute("pageInfo", pageInfo);
		return "html/member";
	}
	

	// 删除
	@RequestMapping(value = "/del_member/{id}")
	public String delMember(@PathVariable("id") int id) {
		memberService.del(id);
		System.out.println("删除id为: " + id + " 的学员");
		return "redirect:/member";
	}
	
	// 删除
	@RequestMapping(value = "/select_del_member/{id}")
	public String selectDelMember(@PathVariable("id") int id) {
		memberService.del(id);
		System.out.println("删除id为: " + id + " 的学员");
		return "redirect:/select_member";
	}




	// 添加操作
	@RequestMapping("/add_member")
	public String addMember(Member member) {
		memberService.add(member);
		System.out.println("添加sno为: " + member.getM_no() + " 的学员");
		return "redirect:/member";
	}


	// 更新操作
	@RequestMapping("/update_member")
	public String update(Member member) {
		// System.out.println("del_id: "+goods.getId());
		System.out.println("更新id为: " + member.getM_no()+ " 的学员");
		System.out.println(member);
		memberService.update(member);
		
		return "redirect:/member";

	}



	// 根据sno及及sname模糊查询
	@RequestMapping("/select_member")
	private String findByName(String sel_member_name, Model model,
			@RequestParam(defaultValue = "1", value = "pageNum") Integer pageNum) {
		model.addAttribute("currUser", AdminController.ADMIN);
		if (sel_member_name != null) {
			selName = sel_member_name;
		}

		PageHelper.startPage(pageNum, 5);
		List<Member> list = memberService.findByName(selName);
		System.out.println(list);
		System.out.println("查询sno或sname Like: " + selName + " 的学员");
		PageInfo<Member> selectInfo = new PageInfo<Member>(list);
		model.addAttribute("pageInfo", selectInfo);
		model.addAttribute("selName", selName);
		return "html/member";

	}




}
