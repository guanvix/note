package com.market.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.market.entity.Admin;
import com.market.service.AdminService;




@Controller
@SessionAttributes({"currUser","students"})
public class AdminController {

	@Autowired
	public static Admin ADMIN=null;
	@Autowired
	private AdminService adminService;
	
	@RequestMapping("/login")
	public String login(Admin admin,ModelMap map) {
		Admin admin2=adminService.login(admin);
		if(admin2!=null) {
			map.addAttribute("currUser", admin2);
			System.out.println("登录成功!");
			ADMIN=admin2;
			return "html/home";
		}
		return "html/login";
	}

    //注销登录
    @RequestMapping("/logout")
    public String logout(HttpSession session)
    {
        System.out.println("推出登陆");
        //session失效
 
        session.removeAttribute("currUser");
        return "redirect:/toLogin";
    }

}
