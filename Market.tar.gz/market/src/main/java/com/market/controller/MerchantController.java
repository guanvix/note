package com.market.controller;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.CustomDateEditor;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.market.entity.Merchant;
import com.market.service.MerchantService;

@Controller
public class MerchantController {

	@Autowired
	private MerchantService merchantService;
	@Autowired
	private static String selName = "";
	

	@InitBinder
	public void initBinder(WebDataBinder binder) {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		dateFormat.setLenient(false);// 是否严格解析时间 false则严格解析 true宽松解析
		binder.registerCustomEditor(Date.class, new CustomDateEditor(dateFormat, true));
	}


	// 查询全部并分页
	@RequestMapping("/merchant")
	public String findAllMember(Model model, @RequestParam(defaultValue = "1", value = "pageNum") Integer pageNum) {
		model.addAttribute("currUser", AdminController.ADMIN);
		PageHelper.startPage(pageNum, 5);
		List<Merchant> list = merchantService.findAllMerchant();
		PageInfo<Merchant> pageInfo = new PageInfo<Merchant>(list);
		model.addAttribute("pageInfo", pageInfo);
		return "html/merchant";
	}
	

//	// 删除
	@RequestMapping(value = "/del_merchant/{id}")
	public String delMember(@PathVariable("id") int id) {
		merchantService.del(id);
		System.out.println("删除id为: " + id + " 的学员");
		return "redirect:/merchant";
	}
	
//	// 删除
//	@RequestMapping(value = "/select_del_member/{id}")
//	public String selectDelMember(@PathVariable("id") int id) {
//		memberService.del(id);
//		System.out.println("删除id为: " + id + " 的学员");
//		return "redirect:/select_member";
//	}
//
//
//
//
	// 添加操作
	@RequestMapping("/add_merchant")
	public String addMember(Merchant merchant) {
		merchantService.add(merchant);
		System.out.println("添加sno为: " + merchant.getMer_no() + " 的学员");
		return "redirect:/merchant";
	}
//
//
	// 更新操作
	@RequestMapping("/update_merchant")
	public String update(Merchant merchant) {
		// System.out.println("del_id: "+goods.getId());
		System.out.println("更新id为: " + merchant.getMer_no()+ " 的学员");
		System.out.println(merchant);
		merchantService.update(merchant);
		
		return "redirect:/merchant";

	}
//
//
//
	// 根据sno及及sname模糊查询
	@RequestMapping("/select_merchant")
	private String findByName(String sel_merchant_name, Model model,
			@RequestParam(defaultValue = "1", value = "pageNum") Integer pageNum) {
		model.addAttribute("currUser", AdminController.ADMIN);
		if (sel_merchant_name != null) {
			selName = sel_merchant_name;
		}

		PageHelper.startPage(pageNum, 5);
		List<Merchant> list = merchantService.findByName(selName);
		System.out.println(list);
		System.out.println("查询sno或sname Like: " + selName + " 的学员");
		PageInfo<Merchant> selectInfo = new PageInfo<Merchant>(list);
		model.addAttribute("pageInfo", selectInfo);
		model.addAttribute("selName", selName);
		return "html/merchant";

	}

//
//

}
