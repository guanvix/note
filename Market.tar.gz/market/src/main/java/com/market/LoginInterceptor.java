package com.market;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.HandlerInterceptor;

import com.market.entity.Admin;



public class LoginInterceptor implements HandlerInterceptor{
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		HttpSession session=request.getSession();
		Admin admin=(Admin)session.getAttribute("currUser");
		if(admin!=null) {
			//已登录
			return true;
		}
		//未登录  重新登录
		response.sendRedirect(request.getContextPath()+"/toLogin");
		return false;
	}
	

}
