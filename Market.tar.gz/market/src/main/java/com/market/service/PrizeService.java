package com.market.service;
import java.util.List;

import org.springframework.stereotype.Service;

import com.market.entity.Prize;

@Service
public interface PrizeService {
	
	public List<Prize> findAllPrize();
	public boolean add(Prize prize);
	public boolean del(int id);
	public boolean update(Prize prize);
	public List<Prize> findByName(String name);
	public Prize findById(int id);




}
