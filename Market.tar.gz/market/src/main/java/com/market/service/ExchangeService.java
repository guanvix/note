package com.market.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.market.entity.Exchange;

@Service
public interface ExchangeService {
	
	public List<Exchange> findAllExchange();
	public boolean add(Exchange exchange);
	public boolean del(int id);
	public boolean update(Exchange exchange);
	public List<Exchange> findByName(String name);
	public Exchange findById(int id);


}
