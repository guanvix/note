package com.market.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.market.entity.Staff;
import com.market.mapper.StaffMapper;
import com.market.service.StaffService;


@Service
public class StaffServiceImpl implements StaffService {
	@Autowired
	private StaffMapper staffMapper;

	@Override
	public List<Staff> findAllStaff() {
		// TODO Auto-generated method stub
		return staffMapper.findAllStaff();
	}

	@Override
	public boolean add(Staff staff) {
		// TODO Auto-generated method stub
		return staffMapper.add(staff);
	}

	@Override
	public boolean del(int id) {
		// TODO Auto-generated method stub
		return staffMapper.del(id);
	}

	@Override
	public boolean update(Staff staff) {
		// TODO Auto-generated method stub
		return staffMapper.update(staff);
	}

	@Override
	public List<Staff> findByName(String name) {
		// TODO Auto-generated method stub
		return staffMapper.findByName(name);
	}

	@Override
	public Staff findById(int id) {
		// TODO Auto-generated method stub
		return staffMapper.findById(id)
				;
	}

}