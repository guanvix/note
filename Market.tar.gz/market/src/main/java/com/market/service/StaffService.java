package com.market.service;
import java.util.List;

import org.springframework.stereotype.Service;

import com.market.entity.Staff;

@Service
public interface StaffService {
	
	public List<Staff> findAllStaff();
	public boolean add(Staff staff);
	public boolean del(int id);
	public boolean update(Staff staff);
	public List<Staff> findByName(String name);
	public Staff findById(int id);

}
