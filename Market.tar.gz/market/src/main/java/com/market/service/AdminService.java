package com.market.service;

import com.market.entity.Admin;

public interface AdminService {
	
	Admin login(Admin admin);

}
