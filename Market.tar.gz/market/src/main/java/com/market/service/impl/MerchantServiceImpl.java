package com.market.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.market.entity.Merchant;
import com.market.mapper.MerchantMapper;
import com.market.service.MerchantService;


@Service
public class MerchantServiceImpl implements MerchantService {
	@Autowired
	private MerchantMapper merchantMapper;
	@Override
	public List<Merchant> findAllMerchant() {
		// TODO Auto-generated method stub
		return merchantMapper.findAllMerchant();
	}

	@Override
	public boolean add(Merchant merchant) {
		// TODO Auto-generated method stub
		return merchantMapper.add(merchant);
	}

	@Override
	public boolean del(int id) {
		// TODO Auto-generated method stub
		return merchantMapper.del(id);
	}

	@Override
	public boolean update(Merchant merchant) {
		// TODO Auto-generated method stub
		return merchantMapper.update(merchant);
	}

	@Override
	public List<Merchant> findByName(String name) {
		// TODO Auto-generated method stub
		return merchantMapper.findByName(name);
	}

	@Override
	public Merchant findById(int id) {
		// TODO Auto-generated method stub
		return merchantMapper.findById(id);
	}

}
