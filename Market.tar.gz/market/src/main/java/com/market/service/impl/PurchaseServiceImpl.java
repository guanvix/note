package com.market.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.market.entity.Purchase;
import com.market.mapper.PurchaseMapper;
import com.market.service.PurchaseService;


@Service
public class PurchaseServiceImpl implements PurchaseService{

	
	@Autowired
	private PurchaseMapper purchaseMapper;
	@Override
	public List<Purchase> findAllPurchase() {
		// TODO Auto-generated method stub
		return purchaseMapper.findAllPurchase();
	}

	@Override
	public boolean add(Purchase purchase) {
		// TODO Auto-generated method stub
		return purchaseMapper.add(purchase);
	}

	@Override
	public boolean del(int id) {
		// TODO Auto-generated method stub
		return purchaseMapper.del(id);
	}

	@Override
	public boolean update(Purchase purchase) {
		// TODO Auto-generated method stub
		return purchaseMapper.update(purchase);
	}

	@Override
	public List<Purchase> findByName(String name) {
		// TODO Auto-generated method stub
		return purchaseMapper.findByName(name);
	}

	@Override
	public Purchase findById(int id) {
		// TODO Auto-generated method stub
		return purchaseMapper.findById(id);
	}

}
