package com.market.service;
import java.util.List;

import com.market.entity.Student;

public interface StudentService {
	
	public List<Student> findAllStudents();
	public boolean add(Student student);
	public boolean del(int id);
	public boolean update(Student student);
	public List<Student> findByName(String name);
	public Student findById(int id);
//	public List<Student> findStudents(int pageNum, int pageSize);



}
