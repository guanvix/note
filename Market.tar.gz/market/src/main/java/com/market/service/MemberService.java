package com.market.service;
import java.util.List;

import org.springframework.stereotype.Service;

import com.market.entity.Member;

@Service
public interface MemberService {
	
	public List<Member> findAllMember();
	public boolean add(Member member);
	public boolean del(int id);
	public boolean update(Member member);
	public List<Member> findByName(String name);
	public Member findById(int id);

}
