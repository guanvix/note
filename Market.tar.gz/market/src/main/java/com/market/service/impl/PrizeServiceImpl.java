package com.market.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.market.entity.Prize;
import com.market.mapper.PrizeMapper;
import com.market.service.PrizeService;


@Service
public class PrizeServiceImpl implements PrizeService {

	
	@Autowired
	private PrizeMapper prizeMapper;
	@Override
	public List<Prize> findAllPrize() {
		// TODO Auto-generated method stub
		return prizeMapper.findAllPrize();
	}

	@Override
	public boolean add(Prize prize) {
		// TODO Auto-generated method stub
		return prizeMapper.add(prize);
	}

	@Override
	public boolean del(int id) {
		// TODO Auto-generated method stub
		return prizeMapper.del(id);
	}

	@Override
	public boolean update(Prize prize) {
		// TODO Auto-generated method stub
		return prizeMapper.update(prize);
	}

	@Override
	public List<Prize> findByName(String name) {
		// TODO Auto-generated method stub
		return prizeMapper.findByName(name);
	}

	@Override
	public Prize findById(int id) {
		// TODO Auto-generated method stub
		return prizeMapper.findById(id);
	}

}
