package com.market.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.market.entity.Member;
import com.market.mapper.MemberMapper;
import com.market.service.MemberService;


@Service
public class MemberServiceImpl implements MemberService{

	
	@Autowired
	private MemberMapper memberMapper;
	@Override
	public List<Member> findAllMember() {
		// TODO Auto-generated method stub
		return memberMapper.findAllMember();
	}

	@Override
	public boolean add(Member member) {
		// TODO Auto-generated method stub
		return memberMapper.add(member);
	}

	@Override
	public boolean del(int id) {
		// TODO Auto-generated method stub
		return memberMapper.del(id);
	}

	@Override
	public boolean update(Member member) {
		// TODO Auto-generated method stub
		return memberMapper.update(member);
	}

	@Override
	public List<Member> findByName(String name) {
		// TODO Auto-generated method stub
		return memberMapper.findByName(name);
	}

	@Override
	public Member findById(int id) {
		// TODO Auto-generated method stub
		return memberMapper.findById(id);
	}

}
