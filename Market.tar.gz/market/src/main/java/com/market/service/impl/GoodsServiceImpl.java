package com.market.service.impl;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.market.entity.Goods;
import com.market.mapper.GoodsMapper;
import com.market.service.GoodsService;


@Service
public class GoodsServiceImpl implements GoodsService {

	
	@Autowired
	private GoodsMapper goodsMapper;
	@Override
	public List<Goods> findAllGoods() {
		// TODO Auto-generated method stub
		return goodsMapper.findAllGoods();
	}

	@Override
	public boolean add(Goods goods) {
		// TODO Auto-generated method stub
		return goodsMapper.add(goods);
	}

	@Override
	public boolean del(int id) {
		// TODO Auto-generated method stub
		return goodsMapper.del(id);
	}

	@Override
	public boolean update(Goods goods) {
		// TODO Auto-generated method stub
		return goodsMapper.update(goods);
	}

	@Override
	public List<Goods> findByName(String name) {
		// TODO Auto-generated method stub
		return goodsMapper.findByName(name);
	}

	@Override
	public Goods findById(int id) {
		// TODO Auto-generated method stub
		return goodsMapper.findById(id);
	}

	
}
