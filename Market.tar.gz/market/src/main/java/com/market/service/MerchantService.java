package com.market.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.market.entity.Merchant;

@Service
public interface MerchantService {
	
	public List<Merchant> findAllMerchant();
	public boolean add(Merchant merchant);
	public boolean del(int id);
	public boolean update(Merchant merchant);
	public List<Merchant> findByName(String name);
	public Merchant findById(int id);

}
