package com.market.service;

import java.util.List;

import com.market.entity.Goods;

public interface GoodsService {
	
	public List<Goods> findAllGoods();
	public boolean add(Goods goods);
	public boolean del(int id);
	public boolean update(Goods goods);
	public List<Goods> findByName(String name);
	public Goods findById(int id);




}
