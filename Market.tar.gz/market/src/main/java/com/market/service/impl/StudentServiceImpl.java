package com.market.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.market.entity.Student;
import com.market.mapper.StudentMapper;
import com.market.service.StudentService;

@Service
public class StudentServiceImpl implements StudentService{

	@Autowired
	private StudentMapper studentMapper;
	@Override
	public List<Student> findAllStudents() {
		// TODO Auto-generated method stub
		return studentMapper.findAllStudents();
	}
	@Override
	public boolean del(int id) {
		// TODO Auto-generated method stub
		return studentMapper.del(id);
		
	}
	@Override
	public Student findById(int id) {
		// TODO Auto-generated method stub
		return studentMapper.findById(id);
	}
	@Override
	public List<Student> findByName(String name) {
		// TODO Auto-generated method stub
		return studentMapper.findByName(name);
	}
	@Override
	public boolean add(Student student) {
		// TODO Auto-generated method stub
		return studentMapper.add(student);
	}
	@Override
	public boolean update(Student student) {
		// TODO Auto-generated method stub
		return studentMapper.update(student);
		
	}

	
}
