package com.market.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.market.entity.Exchange;
import com.market.mapper.ExchangeMapper;
import com.market.service.ExchangeService;


@Service
public class ExchangeServiceImpl implements ExchangeService {

	
	@Autowired
	private ExchangeMapper exchangeMapper;

	@Override
	public List<Exchange> findAllExchange() {
		// TODO Auto-generated method stub
		return exchangeMapper.findAllExchange();
	}

	@Override
	public boolean add(Exchange exchange) {
		// TODO Auto-generated method stub
		return exchangeMapper.add(exchange);
	}

	@Override
	public boolean del(int id) {
		// TODO Auto-generated method stub
		return exchangeMapper.del(id);
	}

	@Override
	public boolean update(Exchange exchange) {
		// TODO Auto-generated method stub
		return exchangeMapper.update(exchange);
	}

	@Override
	public List<Exchange> findByName(String name) {
		// TODO Auto-generated method stub
		return exchangeMapper.findByName(name);
	}

	@Override
	public Exchange findById(int id) {
		// TODO Auto-generated method stub
		return exchangeMapper.findById(id);
	}

	
}
