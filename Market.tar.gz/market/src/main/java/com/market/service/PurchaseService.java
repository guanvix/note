package com.market.service;
import java.util.List;

import org.springframework.stereotype.Service;

import com.market.entity.Purchase;

@Service
public interface PurchaseService {
	
	public List<Purchase> findAllPurchase();
	public boolean add(Purchase purchase);
	public boolean del(int id);
	public boolean update(Purchase purchase);
	public List<Purchase> findByName(String name);
	public Purchase findById(int id);

}
