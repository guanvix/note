package com.market.entity;

public class Merchant {

	private String mer_no;
	private String mer_name;
	private String mer_address;
	private String mer_tel;
	public Merchant() {
		super();
	}
	
	public Merchant(String mer_name, String mer_address, String mer_tel) {
		super();
		this.mer_name = mer_name;
		this.mer_address = mer_address;
		this.mer_tel = mer_tel;
	}

	public Merchant(String mer_no, String mer_name, String mer_address, String mer_tel) {
		super();
		this.mer_no = mer_no;
		this.mer_name = mer_name;
		this.mer_address = mer_address;
		this.mer_tel = mer_tel;
	}
	public String getMer_no() {
		return mer_no;
	}
	public void setMer_no(String mer_no) {
		this.mer_no = mer_no;
	}
	public String getMer_name() {
		return mer_name;
	}
	public void setMer_name(String mer_name) {
		this.mer_name = mer_name;
	}
	public String getMer_address() {
		return mer_address;
	}
	public void setMer_address(String mer_address) {
		this.mer_address = mer_address;
	}
	public String getMer_tel() {
		return mer_tel;
	}
	public void setMer_tel(String mer_tel) {
		this.mer_tel = mer_tel;
	}
	@Override
	public String toString() {
		return "Merchant [mer_no=" + mer_no + ", mer_name=" + mer_name + ", mer_address=" + mer_address + ", mer_tel="
				+ mer_tel + "]";
	}

}
