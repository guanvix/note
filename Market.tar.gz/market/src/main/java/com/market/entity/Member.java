package com.market.entity;

public class Member {
	private int m_no;
	private String m_name;
	private String m_tel;
	private int m_score;
	private int m_sum_score;
	private String m_join_time;
	public Member() {
		super();
	}
	public Member(int m_no, String m_name, String m_tel, int m_score, int m_sum_score, String m_join_time) {
		super();
		this.m_no = m_no;
		this.m_name = m_name;
		this.m_tel = m_tel;
		this.m_score = m_score;
		this.m_sum_score = m_sum_score;
		this.m_join_time = m_join_time;
	}
	public int getM_no() {
		return m_no;
	}
	public void setM_no(int m_no) {
		this.m_no = m_no;
	}
	public String getM_name() {
		return m_name;
	}
	public void setM_name(String m_name) {
		this.m_name = m_name;
	}
	public String getM_tel() {
		return m_tel;
	}
	public void setM_tel(String m_tel) {
		this.m_tel = m_tel;
	}
	public int getM_score() {
		return m_score;
	}
	public void setM_score(int m_score) {
		this.m_score = m_score;
	}
	public int getM_sum_score() {
		return m_sum_score;
	}
	public void setM_sum_score(int m_sum_score) {
		this.m_sum_score = m_sum_score;
	}
	public String getM_join_time() {
		return m_join_time;
	}
	public void setM_join_time(String m_join_time) {
		this.m_join_time = m_join_time;
	}
	@Override
	public String toString() {
		return "Member [m_no=" + m_no + ", m_name=" + m_name + ", m_tel=" + m_tel + ", m_score=" + m_score
				+ ", m_sum_score=" + m_sum_score + ", m_join_time=" + m_join_time + "]";
	}
	

}
