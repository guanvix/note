package com.market.entity;

public class Prize {

	private int p_no;
	private String p_name;
	private String p_brand;
	private int p_amount;
	private int p_score;
	public Prize() {
		super();
	}
	public Prize(int p_no, String p_name, String p_brand, int p_amount, int p_score) {
		super();
		this.p_no = p_no;
		this.p_name = p_name;
		this.p_brand = p_brand;
		this.p_amount = p_amount;
		this.p_score = p_score;
	}
	public int getP_no() {
		return p_no;
	}
	public void setP_no(int p_no) {
		this.p_no = p_no;
	}
	public String getP_name() {
		return p_name;
	}
	public void setP_name(String p_name) {
		this.p_name = p_name;
	}
	public String getP_brand() {
		return p_brand;
	}
	public void setP_brand(String p_brand) {
		this.p_brand = p_brand;
	}
	public int getP_amount() {
		return p_amount;
	}
	public void setP_amount(int p_amount) {
		this.p_amount = p_amount;
	}
	public int getP_score() {
		return p_score;
	}
	public void setP_score(int p_score) {
		this.p_score = p_score;
	}

	
}
