package com.market.entity;

public class Exchange {
	private int e_no;
	private String m_name;  //会员名
	private String p_name;  //礼品名
	private String e_time;
	public Exchange() {
		super();
	}
	public int getE_no() {
		return e_no;
	}
	public void setE_no(int e_no) {
		this.e_no = e_no;
	}
	public String getM_name() {
		return m_name;
	}
	public void setM_name(String m_name) {
		this.m_name = m_name;
	}
	public String getP_name() {
		return p_name;
	}
	public void setP_name(String p_name) {
		this.p_name = p_name;
	}
	public String getE_time() {
		return e_time;
	}
	public void setE_time(String e_time) {
		this.e_time = e_time;
	}
	public Exchange(int e_no, String m_name, String p_name, String e_time) {
		super();
		this.e_no = e_no;
		this.m_name = m_name;
		this.p_name = p_name;
		this.e_time = e_time;
	}
	@Override
	public String toString() {
		return "Exchange [e_no=" + e_no + ", m_name=" + m_name + ", p_name=" + p_name + ", e_time=" + e_time + "]";
	}
	
}
