package com.market.entity;


public class Goods {
	private int g_no;						
	private String g_name;				
	private String g_type;	
	private String g_brand;
	private int g_in_price;				
	private int g_out_price;
	private String g_amount;
	private String g_shelf_life;				
	private String g_production_date;				
	private String g_in_time;	
	private String g_merchant;
	public Goods() {
		super();
	}
	public Goods(int g_no, String g_name, String g_type, String g_brand, int g_in_price, int g_out_price,
			String g_amount, String g_shelf_life, String g_production_date, String g_in_time, String g_merchant) {
		super();
		this.g_no = g_no;
		this.g_name = g_name;
		this.g_type = g_type;
		this.g_brand = g_brand;
		this.g_in_price = g_in_price;
		this.g_out_price = g_out_price;
		this.g_amount = g_amount;
		this.g_shelf_life = g_shelf_life;
		this.g_production_date = g_production_date;
		this.g_in_time = g_in_time;
		this.g_merchant = g_merchant;
	}
	public int getG_no() {
		return g_no;
	}
	public void setG_no(int g_no) {
		this.g_no = g_no;
	}
	public String getG_name() {
		return g_name;
	}
	public void setG_name(String g_name) {
		this.g_name = g_name;
	}
	public String getG_type() {
		return g_type;
	}
	public void setG_type(String g_type) {
		this.g_type = g_type;
	}
	public String getG_brand() {
		return g_brand;
	}
	public void setG_brand(String g_brand) {
		this.g_brand = g_brand;
	}
	public int getG_in_price() {
		return g_in_price;
	}
	public void setG_in_price(int g_in_price) {
		this.g_in_price = g_in_price;
	}
	public int getG_out_price() {
		return g_out_price;
	}
	public void setG_out_price(int g_out_price) {
		this.g_out_price = g_out_price;
	}
	public String getG_amount() {
		return g_amount;
	}
	public void setG_amount(String g_amount) {
		this.g_amount = g_amount;
	}
	public String getG_shelf_life() {
		return g_shelf_life;
	}
	public void setG_shelf_life(String g_shelf_life) {
		this.g_shelf_life = g_shelf_life;
	}
	public String getG_production_date() {
		return g_production_date;
	}
	public void setG_production_date(String g_production_date) {
		this.g_production_date = g_production_date;
	}
	public String getG_in_time() {
		return g_in_time;
	}
	public void setG_in_time(String g_in_time) {
		this.g_in_time = g_in_time;
	}
	public String getG_merchant() {
		return g_merchant;
	}
	public void setG_merchant(String g_merchant) {
		this.g_merchant = g_merchant;
	}
	
	
	
	

}
