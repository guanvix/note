package com.market.entity;

public class Purchase {
	private int pur_no;
	private int g_no;
	private int pur_price;
	private int pur_amount;
	private int pur_sum_price;
	private String pur_time;
	private String pur_remarks;
	public Purchase() {
		super();
	}
	
	public Purchase(int pur_no, int g_no, int pur_price, int pur_amount, String pur_time, String pur_remarks) {
		super();
		this.pur_no = pur_no;
		this.g_no = g_no;
		this.pur_price = pur_price;
		this.pur_amount = pur_amount;
		this.pur_time = pur_time;
		this.pur_remarks = pur_remarks;
	}

	public Purchase(int pur_no, int g_no, int pur_price, int pur_amount, int pur_sum_price, String pur_time,
			String pur_remarks) {
		super();
		this.pur_no = pur_no;
		this.g_no = g_no;
		this.pur_price = pur_price;
		this.pur_amount = pur_amount;
		this.pur_sum_price = pur_sum_price;
		this.pur_time = pur_time;
		this.pur_remarks = pur_remarks;
	}
	public int getPur_no() {
		return pur_no;
	}
	public void setPur_no(int pur_no) {
		this.pur_no = pur_no;
	}
	public int getG_no() {
		return g_no;
	}
	public void setG_no(int g_no) {
		this.g_no = g_no;
	}
	public int getPur_price() {
		return pur_price;
	}
	public void setPur_price(int pur_price) {
		this.pur_price = pur_price;
	}
	public int getPur_amount() {
		return pur_amount;
	}
	public void setPur_amount(int pur_amount) {
		this.pur_amount = pur_amount;
	}
	public int getPur_sum_price() {
		return pur_sum_price;
	}
	public void setPur_sum_price(int pur_sum_price) {
		this.pur_sum_price = pur_sum_price;
	}
	public String getPur_time() {
		return pur_time;
	}
	public void setPur_time(String pur_time) {
		this.pur_time = pur_time;
	}
	public String getPur_remarks() {
		return pur_remarks;
	}
	public void setPur_remarks(String pur_remarks) {
		this.pur_remarks = pur_remarks;
	}

	@Override
	public String toString() {
		return "Purchase [pur_no=" + pur_no + ", g_no=" + g_no + ", pur_price=" + pur_price + ", pur_amount="
				+ pur_amount + ", pur_sum_price=" + pur_sum_price + ", pur_time=" + pur_time + ", pur_remarks="
				+ pur_remarks + "]";
	}
	

}
