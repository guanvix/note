package com.market.entity;


//学员实体类
public class Student {
	private int id;						//学员id
	private String sno;					//学员编号
	private String sname;				//学员姓名
	private String age;					//学员年龄
	private String sex;					//学员性别
	private String tel;					//学员联系电话
	private String address;				//学员住址
	private String admisson_time;		//学员入学时间
	private int is_del;					//记录是否存在,1->存在，0->已删除
	public Student() {
		super();
	}
	
	
	public Student(String sno, String sname, String age, String sex, String tel, String address, String admisson_time,
			int is_del) {
		super();
		this.sno = sno;
		this.sname = sname;
		this.age = age;
		this.sex = sex;
		this.tel = tel;
		this.address = address;
		this.admisson_time = admisson_time;
		this.is_del = is_del;
	}


	public Student(int id, String sno, String sname, String age, String sex, String tel, String address,
			String admisson_time, int is_del) {
		super();
		this.id = id;
		this.sno = sno;
		this.sname = sname;
		this.age = age;
		this.sex = sex;
		this.tel = tel;
		this.address = address;
		this.admisson_time = admisson_time;
		this.is_del = is_del;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getSno() {
		return sno;
	}
	public void setSno(String sno) {
		this.sno = sno;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getAdmisson_time() {
		return admisson_time;
	}
	public void setAdmisson_time(String admisson_time) {
		this.admisson_time = admisson_time;
	}
	public int getIs_del() {
		return is_del;
	}
	public void setIs_del(int is_del) {
		this.is_del = is_del;
	}
	@Override
	public String toString() {
		return "Student [id=" + id + ", sno=" + sno + ", sname=" + sname + ", age=" + age + ", sex=" + sex + ", tel="
				+ tel + ", address=" + address + ", admisson_time=" + admisson_time + ", is_del=" + is_del + "]";
	}
	
	
	
	
	
	
	
	

}
