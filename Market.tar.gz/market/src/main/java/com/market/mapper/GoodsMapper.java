package com.market.mapper;
import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.market.entity.Goods;


@Mapper
public interface GoodsMapper {
	public List<Goods> findAllGoods();	
	public boolean add(Goods Goods);
	public boolean del(int id);
	public boolean update(Goods Goods);
	public Goods findById(int id);
	public List<Goods> findByName(String name);
}
