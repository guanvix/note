package com.market.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.market.entity.Merchant;


@Mapper
public interface MerchantMapper {
	public List<Merchant> findAllMerchant();	
	public boolean add(Merchant merchant);
	public boolean del(int id);
	public boolean update(Merchant merchant);
	public Merchant findById(int id);
	public List<Merchant> findByName(String name);
}
