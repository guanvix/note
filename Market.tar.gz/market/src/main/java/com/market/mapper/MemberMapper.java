package com.market.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.market.entity.Member;

@Mapper
public interface MemberMapper {
	public List<Member> findAllMember();	
	public boolean add(Member member);
	public boolean del(int id);
	public boolean update(Member member);
	public Member findById(int id);
	public List<Member> findByName(String name);
}
