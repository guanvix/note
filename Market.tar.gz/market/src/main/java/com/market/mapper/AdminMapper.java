package com.market.mapper;

import org.apache.ibatis.annotations.Mapper;

import com.market.entity.Admin;

//管理员Mapper接口
@Mapper
public interface AdminMapper {
	//查找管理员
	Admin findAdmin(Admin admin);

}
