package com.market.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.market.entity.Prize;


@Mapper
public interface PrizeMapper {
	public List<Prize> findAllPrize();	
	public boolean add(Prize prize);
	public boolean del(int id);
	public boolean update(Prize prize);
	public Prize findById(int id);
	public List<Prize> findByName(String name);
}