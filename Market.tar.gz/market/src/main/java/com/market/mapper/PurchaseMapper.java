package com.market.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.market.entity.Purchase;

@Mapper
public interface PurchaseMapper {
	public List<Purchase> findAllPurchase();	
	public boolean add(Purchase purchase);
	public boolean del(int id);
	public boolean update(Purchase purchase);
	public Purchase findById(int id);
	public List<Purchase> findByName(String name);
}
