package com.market.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.market.entity.Staff;

@Mapper
public interface StaffMapper {
	public List<Staff> findAllStaff();	
	public boolean add(Staff staff);
	public boolean del(int id);
	public boolean update(Staff staff);
	public Staff findById(int id);
	public List<Staff> findByName(String name);
}
