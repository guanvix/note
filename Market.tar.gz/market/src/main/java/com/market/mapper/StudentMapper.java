package com.market.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.market.entity.Student;

//学学员员Mapper接口
@Mapper
public interface StudentMapper {
	
	//查找所有有学员
	public List<Student> findAllStudents();
	
	//添加学员
	public boolean add(Student student);

	//删除学员
	public boolean del(int id);
	
	//更新学员
	public boolean update(Student student);
	
	//通过id查找学员
	public Student findById(int id);
	
	//通过名字查找学员
	public List<Student> findByName(String name);
	
}
