package com.market.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import com.market.entity.Exchange;


@Mapper
public interface ExchangeMapper {
	public List<Exchange> findAllExchange();	
	public boolean add(Exchange exchange);
	public boolean del(int id);
	public boolean update(Exchange exchange);
	public Exchange findById(int id);
	public List<Exchange> findByName(String name);
}